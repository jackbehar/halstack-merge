import React from 'react';
import GridItem from '../GridItem';

export default (
  <GridItem uxpId="grid-item">Grid Item</GridItem>
);
